'''
1*1=1
1*2=2    2*2=4
1*3=3    2*3=6    3*3=9
...      j*i=a
'''
# for i in range(1,10): #控制层数走向
#     for j in range(1,i+1):
#         print(j,"x",i,"=",(j*i),"\t",end='') #end='' 结束符
#     print()

# i=1   #层数
# while i<=9:
#     j=1
#     while j<=i:
#         print(j,'x',i,'=',(i*j),'\t',end='')
#         j = j + 1
#     i=i+1
#     print()         # 正序

i=9
while i>0:
    j=1
    while j<=i:
        print(j, 'x', i, '=', (i * j), '\t', end='')
        j=j+1
    i=i-1
    print()

