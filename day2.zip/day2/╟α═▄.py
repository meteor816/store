'''
井高20m,白天爬3m,晚上掉2m
'''
sum=0
i=1
while (20-sum)>0:  #sum<=20
    sum=sum+3
    if sum>=20:
        break
    sum=sum-2
    if sum>=20:
        break
    i=i+1
print("青蛙第",i,'天出来')

