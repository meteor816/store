'''
用户名：root  密码：admin
'''
i=0  #登录次数
while i<3:
    name= input("请输入用户名：", )
    pwd=input("请输入密码：",)
    i=i+1
    if name=="root" and pwd=="admin":
        print("系统登录成功")
        break
    else:
        print("密码或用户名输入错误")
        if i>2:
            print("系统已锁定")
