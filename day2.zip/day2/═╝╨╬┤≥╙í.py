
for i in range(0,7):   #控制行数走向
    for j in range(7-i):  #内层循环空格数
        print(" ",end="") #end="" 结束符
    for q in range(i+1):  #内层循环个数
        print(" *",end="")
    print()
