
import random
a=float(input("请输入第一条边的长度"),)
b=float(input("请输入第二条边的长度"),)
c=float(input("请输入第三条边的长度"),)
if a+b>c or a+c>b or b+c>a:
    print("可以构成三角形")
    if a==b==c:
        print("三角形为等边三角形")
    elif a==b or a==c or b==c:
        print("三角形为等腰三角形")
    elif a*a+b*b==c*c or b*b+c*c==a*a  or a*a+c*c==b*b:
        print("三角形为直角三角形")
    else:
        print("三角形为普通三角形")
else:
    print("不构成三角形")
