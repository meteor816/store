i=0
sum=0
ss=[]
while i<10:
    a=float(input("请输入",))
    sum=sum+a
    i=i+1
    ss.append(a)
# average = sum / len(ss)
max=ss[0]
for v in range(0,len(ss)):
    if ss[v]>max:
        max=ss[v]
print(ss,"和为",sum)
print("平均数为",sum / len(ss))
print("最大数为",max)
