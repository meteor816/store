'''
 判断
    单分支    if 。。。。。Else
    多分支     if判断条件 elif 判断条件。。。。。。Else
'''
a=input("请输入一个数字")
a=int(a)
if a ==1: # 如果a等于1，那么运行下面的代码
    print("成功1",a)
elif a==2:
    print("也算成功2",a)
elif a==3:
    print("也算成功3", a)
elif a == 4:
    print("也算成功4", a)
else:
    print("失败", a)
