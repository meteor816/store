'''
实现输入10个数字，
并打印10个数的求和结果
# '''


# ss=[1,2,3,4,5]
# for i in ss:
#     print(i)
#
# for i in range(0,len(ss)):
#     print(ss[i])

# i=0
# sum=0
# ss=[]
# while i<10:
#     a=float(input("请输入",))
#     sum=sum+a
#     i=i+1
#     ss.append(a)
# print(ss,"和为",sum)

i=0
sum=0
while i<10:
    a=float(input("请输入："))
    sum=sum+a
    i=i+1
print("求和",sum)





















