import random
num=random.randint(50,150)
print("输出",num)