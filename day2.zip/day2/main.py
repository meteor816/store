'''
猜字游戏
需求：
1、猜的数字是系统产生的，不是自己定义的
2、键盘输入的   操作完填入：input（“提示”）
3、判断			操作完填入：if判断条件 elif 判断条件。。。。。。Else
4、循环			操作完填入：while 条件循环
任务：初始资金为100 每猜一次扣除10 资金为0或者猜对 结束游戏
    猜大，猜小
'''
import  random
#    随机数函数（范围（初始，终止））
num=random.randint(0,5)# 随机数
#print(num)#打印一个随机数
while True:
    a=input("请输入一个数字") #你输入的数字
    a=int(a) #把a转换成int类型
    if a == num:# a是你输入的数字  num是随机数  如果a等于num运行下面的代码
        print("成功",a)
        break
    else:
        print("失败",a)
