import random
num=random.randint(0,100)
i=200
n=0
while True:
    if i==0:
        print("没有金币了，欢迎下次再来")
        break
    else:
        a=input("请输入一个数字")
        a=int(a)
        if a==num:
            print("成功了,金币余额为",i)
            break
        elif a>num:
            print("大了，金币余额为：",i)
            i=i-10
            n=n+1
        else:
            i = i - 10
            print("小了，金币余额为：",i)
            n=n+1
    if n>10:
        print("系统已锁定")
        break











