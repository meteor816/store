A=56
B=78
A=A+B
B=A-B
A=A-B
print("A=",A)
print("B=",B)
# A,B=B,A
# print(A,B)

